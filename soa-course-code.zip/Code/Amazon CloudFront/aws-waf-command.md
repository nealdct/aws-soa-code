# Use this command on CloudShell to trip the WAF rule
for i in {1..140}; do curl https://dcttestlabs.link/; done